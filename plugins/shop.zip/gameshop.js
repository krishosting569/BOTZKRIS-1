let handler = async m => m.reply(`
*[MENU GAMSHOP]*

*⚠GRUP⚠*

*• https://chat.whatsapp.com/KeyflNVrBsN6ctjfevI3n0*

*➥ !ffid (list dm via id)*

*➥ !fflog (list dm via login)*

*➥ !shoppay (list pembayaran)*

*➥ !publogin (list dm pubg via login)*
`.trim()) // Tambah n kalo mau
handler.help = ['gamshop']
handler.tags = ['gamshop']
handler.command = /^gamshop$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = true
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
