let handler = async m => m.reply(`
*METODE PEMBAYARAN*

*GOPAY*
085786211623
kris Store

*DANA* 
0882007324217
Krisdi Firmansyah 

*OVO*
085786211623
Krisdi Firmansyah
`.trim()) // Tambah sendiri kalo mau
handler.help = ['shoppay']
handler.tags = ['bisnis']
handler.command = /^(shoppay)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = true
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
